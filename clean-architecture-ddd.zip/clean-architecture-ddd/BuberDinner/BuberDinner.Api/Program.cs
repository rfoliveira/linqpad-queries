// Outra forma de fazer que a pessoa
// do vídeo considera mais organizada (mas eu não)
// var builder = WebApplication.CreateBuilder(args)
// {
//     builder.Services.AddControllers();
// }

// var app = builder.Build()
// {
//     app.UseHttpsRedirection();
//     app.MapControllers();
//     app.Run();
// }

// using BuberDinner.Api.Errors;
// using BuberDinner.Api.Filters;
// using BuberDinner.Api.Middleware;
// using System.Net;
using BuberDinner.Api.Common.Errors;
using BuberDinner.Application;
using BuberDinner.Infrastructure;
// using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc.Infrastructure;
// using Microsoft.AspNetCore.Mvc.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddApplication()
    .AddInfrastructure(builder.Configuration);

// Forma 2: usando exception filter de forma global
// builder.Services.AddControllers(options => options.Filters.Add<ErrorHandlingFilterAttribute>());

// Forma 3: considerando a forma 2 de maneira mais otimizada
builder.Services.AddControllers();

// Forma 3: registrando a classe global de erros como singleton
// Forma 4: comentar a linha abaixo
builder.Services.AddSingleton<ProblemDetailsFactory, BuberDinnerProblemDetailsFactory>();

var app = builder.Build();

// Forma 3: Através do framework, já será retornado o 
// objeto padrão RFC7230, de acordo com o status code informado,
// não precisando definir novamente esse objeto como da forma 2.
app.UseExceptionHandler("/error");

// Forma 4: outra maneira de se registrar de forma global, 
// usando o padrão RFC7230, mas sem usar uma classe diferente do
// DefaultProblemDetailsFactory, não precisando do singleton abaixo:
// builder.Services.AddSingleton<ProblemDetailsFactory, BuberDinnerProblemDetailsFactory>();
// app.Map("/error", (HttpContext context) => 
// {
//     Exception? exception = context.Features.Get<IExceptionHandlerFeature>()?.Error;
    
//     // todo: ver depois como obter o status code baseado no tipo da exception
//     int code = exception?.GetType().ToString() switch 
//     {
//         "ApplicationException" => (int)HttpStatusCode.BadRequest,
//         "ArgumentException" => (int)HttpStatusCode.BadRequest,
//         _ => (int)HttpStatusCode.InternalServerError
//     };

//     return Results.Problem(title: exception?.Message, statusCode: code);
// });

// Forma 1: todas as exceptions serão capturadas por esse middleware
// e retornado aqui que está programado no HandleExceptionAsync
// app.UseMiddleware<ErrorHandlingMiddleware>();
app.UseHttpsRedirection();
app.MapControllers();

app.Run();