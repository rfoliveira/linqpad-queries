using BuberDinner.Application.Common.Errors;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace BuberDinner.Api.Controllers;

public class ErrorsController : ControllerBase
{
    [Route("/error")]
    public IActionResult Error()
    {
        Exception? exception = HttpContext.Features.Get<IExceptionHandlerFeature>()?.Error;
        // Irá retornar um objeto padrão RFC7230 de acordo 
        // com o status code informado
        // Ex.: return Problem(title: exception?.Message, statusCode: 400);

        var (statusCode, message) = exception switch 
        {
            // Isso não é recomendado em termos de segurança (essa mensagem)...
            // DuplicateEmailException => (StatusCodes.Status409Conflict, "Email already exists"),
            IServiceException service => ((int)service.StatusCode, service.ErrorMessage),
            _ => (StatusCodes.Status500InternalServerError, "An unexcepted error occurred")
        };

        return Problem(statusCode: statusCode, title: message);
    }
}