using BuberDinner.Application.Common.Errors;
using BuberDinner.Application.Services.Authentication;
using BuberDinner.Contracts.Authentication;
using Microsoft.AspNetCore.Mvc;
using OneOf;

namespace BuberDinner.Api.Controllers;

[ApiController]
[Route("auth")]
public class AuthenticationController : ControllerBase
{
    private readonly IAuthenticationService _authService;

    public AuthenticationController(IAuthenticationService authService)
    {
        _authService = authService;
    }

    [HttpPost("register")]
    public async Task<IActionResult> RegisterAsync(RegisterRequest request)
    {
        // var authResult = await _authService.RegisterAsync(
        //     request.FirstName, 
        //     request.LastName, 
        //     request.Email, 
        //     request.Password
        // );

        // var response = new AuthenticationResponse(
        //     authResult.user.Id,
        //     authResult.user.FirstName,
        //     authResult.user.LastName,
        //     authResult.user.Email,
        //     authResult.Token
        // );

        // return await Task.FromResult(Ok(authResult));

        var registerResult = await _authService.RegisterAsync(
            request.FirstName, 
            request.LastName, 
            request.Email, 
            request.Password
        );

        // if (registerResult.IsT0)
        // {
        //     var authResult = registerResult.AsT0;
        //     var response = MapAuthResult(authResult);

        //     return await Task.FromResult(Ok(response));
        // }

        // return await Task.FromResult(Problem(statusCode: StatusCodes.Status409Conflict, title: "Email already exists"));

        // Forma mais limpa de se fazer o IF acima (com OneOf<>...)
        return await Task.FromResult(
            registerResult.Match(
                authResult => Ok(MapAuthResult(authResult)),
                _ => Problem(statusCode: StatusCodes.Status409Conflict, title: "Email already exists")
            )
        );
    }

    private static AuthenticationResponse MapAuthResult(AuthenticationResult authResult)
    {
        return new AuthenticationResponse(
            authResult.user.Id,
            authResult.user.FirstName,
            authResult.user.LastName,
            authResult.user.Email,
            authResult.Token
        );
    }

    [HttpPost("login")]
    public async Task<IActionResult> LoginAsync(LoginRequest request)
    {
        var authResult = await _authService.LoginAsync(request.Email, request.Password);
        var response = new AuthenticationResponse(
            authResult.user.Id,
            authResult.user.FirstName,
            authResult.user.LastName,
            authResult.user.Email,
            authResult.Token
        );

        return await Task.FromResult(Ok(authResult));
    }
}