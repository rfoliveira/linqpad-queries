using BuberDinner.Application.Common.Errors;
using BuberDinner.Application.Common.Interfaces.Authentication;
using BuberDinner.Application.Common.Interfaces.Persistence;
using BuberDinner.Domain.Entities;
using OneOf;

namespace BuberDinner.Application.Services.Authentication;

public class AuthenticationService : IAuthenticationService
{
    private readonly IJWtTokenGenerator _jwtTokenGenerator;
    private readonly IUserRepository _userRepo;
    public AuthenticationService(
        IJWtTokenGenerator jwtTokenGenerator,
        IUserRepository userRepo)
    {
        _jwtTokenGenerator = jwtTokenGenerator;
        _userRepo = userRepo;
    }

    // public Task<AuthenticationResult> RegisterAsync(string firstName, string lastName, string email, string password)
    // {
    //     // Check if user already exists
    //     // 1. Validate the user doesnt exist
    //     if (_userRepo.GetUserByEmail(email) != null)
    //         throw new DuplicateEmailException();
    //         //throw new ApplicationException("User with given email already exists");

    //     var user = new User
    //     {
    //         FirstName = firstName,
    //         LastName = lastName,
    //         Email = email,
    //         Password = password
    //     };

    //     // Create the user (generate the unique ID) & persist do DB
    //     _userRepo.Add(user);

    //     // Create JWT token
    //     var token = _jwtTokenGenerator.GenerateToken(user).Result;
        
    //     return Task.FromResult(new AuthenticationResult(user, token));
    // }

    public Task<AuthenticationResult> LoginAsync(string email, string password)
    {
        var user = _userRepo.GetUserByEmail(email);

        if (user == null)
            throw new ApplicationException("Invalid user");

        if (user.Password != password)
            throw new ApplicationException("Wrong password");

        var token = _jwtTokenGenerator.GenerateToken(user).Result;

        return Task.FromResult(new AuthenticationResult(user, token));
    }

    public Task<OneOf<AuthenticationResult, DuplicateEmailError>> RegisterAsync(string firstName, string lastName, string email, string password)
    {
        // Check if user already exists
        // 1. Validate the user doesnt exist
        if (_userRepo.GetUserByEmail(email) != null)
            return Task.FromResult<OneOf<AuthenticationResult, DuplicateEmailError>>(new DuplicateEmailError());

        var user = new User
        {
            FirstName = firstName,
            LastName = lastName,
            Email = email,
            Password = password
        };

        // Create the user (generate the unique ID) & persist do DB
        _userRepo.Add(user);

        // Create JWT token
        var token = _jwtTokenGenerator.GenerateToken(user).Result;
        
        return Task.FromResult<OneOf<AuthenticationResult, DuplicateEmailError>>(new AuthenticationResult(user, token));
    }
}