using BuberDinner.Domain.Entities;

namespace BuberDinner.Application.Common.Interfaces.Authentication;

public interface IJWtTokenGenerator
{
    Task<string> GenerateToken(User user);
}