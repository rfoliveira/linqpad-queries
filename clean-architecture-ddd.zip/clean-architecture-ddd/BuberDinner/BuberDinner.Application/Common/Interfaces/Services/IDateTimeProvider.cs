namespace BuberDinner.Application.Common.Interfaces.Services;

public interface IDateTimeProvider
{
    // O cara do vídeo diz que recomenda usar
    // DateTimeOffset Now { get; }, ao invés disso aqui
    DateTime UtcNow { get; }
}