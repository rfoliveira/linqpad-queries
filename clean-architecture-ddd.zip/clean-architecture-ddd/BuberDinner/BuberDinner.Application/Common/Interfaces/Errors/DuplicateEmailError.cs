namespace BuberDinner.Application.Common.Errors;

public record struct DuplicateEmailError();