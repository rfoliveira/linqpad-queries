# clean-architecture-ddd
Repositório do tutorial de aspnet 6 + clean architecture + ddd 
Ref.: https://www.youtube.com/watch?v=fhM0V2N1GpY&list=PLzYkqgWkHPKBcDIP5gzLfASkQyTdy0t4k&index=2

# Commands (in powershell)
- dotnet new sln -o BuberDinner
- cd BuberDinner
- dotnet new webapi -o BuberDinner.Api
- dotnet new classlib -o BuberDinner.Contracts
- dotnet new classlib -o BuberDinner.Infrastructure
- dotnet new classlib -o BuberDinner.Application
- dotnet new classlib -o BuberDinner.Domain
- cd ..
- dotnet sln add (ls -r **/*.csproj)
- dotnet add .\BuberDinner.Api\ reference .\BuberDinner.Contracts\ .\BuberDinner.Application\
- dotnet add .\BuberDinner.Infrastructure\ reference .\BuberDinner.Application\
- dotnet add .\BuberDinner.Application\ reference .\BuberDinner.Domain\
- dotnet add .\BuberDinner.Api\ reference .\BuberDinner.Infrastructure\
- dotnet add .\BuberDinner.Application\ package Microsoft.Extensions.DependencyInjection.Abstractions
- dotnet add .\BuberDinner.Infrastructure\ package Microsoft.Extensions.DependencyInjection.Abstractionsions
- dotnet add .\BuberDinner.Infrastructure\ package System.IdentityModel.Tokens.Jwt --version 6.25.0
- dotnet add .\BuberDinner.Infrastructure\ package Microsoft.Extensions.Configuration --version 6.0.1
- dotnet add .\BuberDinner.Infrastructure\ package Microsoft.Extensions.Options.ConfigurationExtensions --version 6.0.0
- dotnet add .\BuberDinner.Application\ package oneof
- dotnet add .\BuberDinner.Api\ package oneof

Substituindo o uso da secret no appsettings.json para dotnet user secrets:
- Deixar em branco no appsettings.json e executar:
-- dotnet user-secrets init --project .\BuberDinner.Api\

- Definindo a chave e o valor
-- dotnet user-secrets set --project .\BuberDinner.Api\ "JwtSettings:Secret" "super-secret-key-from-user-secrets"

- Listando as chaves
dotnet user-secrets list --project .\BuberDinner.Api\ 